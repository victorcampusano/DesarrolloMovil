const moneda = new Intl.NumberFormat('es-DO', { style: 'currency', currency: 'DOP' });
// La prop resultado puede ser null: en ese caso mostramos instrucciones.
export default function ResultadoSalario({ resultado }) {
  return <section className="panel results" aria-live="polite"><div className="section-label"><span className="step">02</span> Resumen del pago</div>
    {resultado ? <><div className="total-label">SALARIO SEMANAL</div><div className="total">{moneda.format(resultado.total)}</div><p className="total-hint">Total antes de deducciones</p><div className="line"/><div className="detail"><span>Horas normales</span><strong>{resultado.horasNormales} h</strong></div><div className="detail"><span>Horas extras</span><strong>{resultado.horasExtras} h</strong></div><div className="detail"><span>Pago ordinario</span><strong>{moneda.format(resultado.pagoNormal)}</strong></div><div className="detail"><span>Pago por horas extras</span><strong>{moneda.format(resultado.pagoExtra)}</strong></div><div className="note">Las horas superiores a 40 se pagan con un recargo del 50 %.</div></> : <div className="empty"><div className="empty-icon">↗</div><h2>Tu resultado aparecerá aquí</h2><p>Introduce las horas trabajadas y la tarifa por hora para calcular el salario.</p></div>}
  </section>;
}
