import { useState } from 'react';
import Header from './components/Header.jsx';
import SalarioForm from './components/SalarioForm.jsx';
import ResultadoSalario from './components/ResultadoSalario.jsx';
import { calcularSalario } from './utils/calcularSalario.js';

export default function App() {
  // useState conserva los datos entre renderizados del componente.
  const [horas, setHoras] = useState('');
  const [tarifa, setTarifa] = useState('');
  const [resultado, setResultado] = useState(null);
  const [error, setError] = useState('');

  function manejarCalculo() {
    setError('');
    setResultado(null);
    if (horas.trim() === '' || tarifa.trim() === '') {
      setError('Completa ambos campos antes de calcular.');
      return;
    }
    try {
      setResultado(calcularSalario(Number(horas), Number(tarifa)));
    } catch (err) {
      setError(err.message);
    }
  }

  function limpiar() {
    setHoras(''); setTarifa(''); setResultado(null); setError('');
  }

  return <div className="app"><Header/><main className="layout"><SalarioForm horas={horas} tarifa={tarifa} onHorasChange={setHoras} onTarifaChange={setTarifa} onCalcular={manejarCalculo} onLimpiar={limpiar} error={error}/><ResultadoSalario resultado={resultado}/></main><footer>Proyecto educativo · React JS · Ejercicio 01</footer></div>;
}
