// Props: valores y funciones que recibimos del componente App.
export default function SalarioForm({ horas, tarifa, onHorasChange, onTarifaChange, onCalcular, onLimpiar, error }) {
  function manejarEnvio(evento) {
    evento.preventDefault(); // Evita que el navegador recargue la página.
    onCalcular();
  }
  return (
    <form className="panel form" onSubmit={manejarEnvio} noValidate>
      <div className="section-label"><span className="step">01</span> Datos del trabajador</div>
      <label htmlFor="horas">Horas trabajadas en la semana</label>
      <input id="horas" type="number" min="0" step="any" placeholder="Ej. 45" value={horas} onChange={(e) => onHorasChange(e.target.value)} />
      <small>La jornada ordinaria es de 40 horas.</small>
      <label htmlFor="tarifa">Tarifa por hora (RD$)</label>
      <input id="tarifa" type="number" min="0" step="any" placeholder="Ej. 200" value={tarifa} onChange={(e) => onTarifaChange(e.target.value)} />
      <small>Las horas extras se pagan al 150 % de esta tarifa.</small>
      {error && <p className="error" role="alert">{error}</p>}
      <div className="actions"><button type="submit" className="primary">Calcular salario →</button><button type="button" className="secondary" onClick={onLimpiar}>Limpiar</button></div>
    </form>
  );
}
