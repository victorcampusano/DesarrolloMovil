// Componente de presentación: no necesita estado.
export default function Header() {
  return <header className="header"><div className="brand">NÓMINA <span>LAB</span></div><p className="eyebrow">EJERCICIO 01 · INTRODUCCIÓN A REACT</p><h1>Calculadora de salario semanal</h1><p className="subtitle">Calcula el pago ordinario y las horas extras de forma sencilla.</p></header>;
}
