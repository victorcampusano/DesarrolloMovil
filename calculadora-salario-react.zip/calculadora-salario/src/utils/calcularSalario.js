// Función pura: recibe datos y devuelve resultados sin modificar la interfaz.
export function calcularSalario(horas, tarifa) {
  if (!Number.isFinite(horas) || !Number.isFinite(tarifa) || horas < 0 || tarifa < 0) {
    throw new Error('Las horas y la tarifa deben ser números no negativos.');
  }
  const horasNormales = Math.min(horas, 40);
  const horasExtras = Math.max(horas - 40, 0);
  const pagoNormal = horasNormales * tarifa;
  const pagoExtra = horasExtras * tarifa * 1.5;
  return { horasNormales, horasExtras, pagoNormal, pagoExtra, total: pagoNormal + pagoExtra };
}
