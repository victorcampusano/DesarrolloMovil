# Calculadora de salario semanal — React JS

## Objetivo
Resolver el ejercicio 01 del documento **30 ejercicios**, página 2, mediante una aplicación web desarrollada en React.

## Enunciado
Un trabajador cobra por horas. Hasta 40 horas semanales se pagan a tarifa normal; las horas superiores a 40 reciben un incremento del 50 %. Se debe calcular el salario semanal. Esta aplicación agrega un desglose y validaciones para facilitar el aprendizaje.

## Requisitos
- Node.js compatible con Vite 7 (20.19+ o 22.12+)
- npm

## Instalación
```bash
npm install
npm run dev
```
Abre la dirección local mostrada por Vite. Para compilar: `npm run build`.

## Organización
- `src/main.jsx`: punto de entrada que monta React en el HTML.
- `src/App.jsx`: componente principal; administra el estado y las acciones.
- `src/components/Header.jsx`: encabezado de la aplicación.
- `src/components/SalarioForm.jsx`: formulario controlado; recibe valores y funciones mediante props.
- `src/components/ResultadoSalario.jsx`: muestra el desglose o un mensaje inicial.
- `src/utils/calcularSalario.js`: función pura que contiene la regla del negocio.
- `src/App.css`: estilos y adaptación a pantallas móviles.

## Conceptos de React
**Componente:** función que devuelve JSX, por ejemplo `Header`.

**JSX:** sintaxis similar a HTML dentro de JavaScript. En JSX se usa `className` en lugar de `class`.

**Props:** datos que un componente padre entrega a un hijo. `App` pasa `horas` y `onHorasChange` a `SalarioForm`.

**Estado (`useState`):** datos que pueden cambiar y provocar una actualización visual. `const [horas, setHoras] = useState('')` guarda el valor escrito.

**Formulario controlado:** el `value` de cada `input` procede del estado y `onChange` lo actualiza.

**Eventos:** `onSubmit` ejecuta una función; `preventDefault()` evita recargar la página.

**Renderizado condicional:** `resultado ? ... : ...` decide qué mostrar según haya un cálculo.

**Función pura:** `calcularSalario` no modifica el estado ni la pantalla; solo recibe entradas y devuelve resultados.

**Flujo de datos:** `App` guarda el estado → pasa valores y callbacks a `SalarioForm` → el usuario modifica campos → React actualiza la vista → se calcula el salario → `ResultadoSalario` recibe el resultado por props.

## Fórmulas
```js
horasNormales = Math.min(horas, 40)
horasExtras = Math.max(horas - 40, 0)
pagoNormal = horasNormales * tarifa
pagoExtra = horasExtras * tarifa * 1.5
total = pagoNormal + pagoExtra
```

## Pruebas sugeridas
| Horas | Tarifa | Resultado esperado |
|---:|---:|---:|
| 40 | 200 | RD$8,000 |
| 45 | 200 | RD$9,500 |
| 30 | 100 | RD$3,000 |
| 0 | 200 | RD$0 |
| -2 | 200 | Error de validación |
| 45 | -5 | Error de validación |

## Actividades para estudiantes
1. Cambia el texto y los colores del encabezado.
2. Agrega un campo de nombre del trabajador y muéstralo en el resultado.
3. Agrega un botón para calcular con Enter y comprueba su funcionamiento.
4. Explica qué cambia si se elimina `preventDefault()`.
5. Modifica temporalmente el factor 1.5 por 2 y prueba las diferencias.
6. Explica por qué la lógica de negocio está separada del componente visual.

## Nota
El resultado representa el salario bruto según la regla del ejercicio, sin deducciones de nómina. No pretende representar todos los aspectos de la legislación laboral dominicana.
